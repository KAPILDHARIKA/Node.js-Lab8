module.exports = {
    search: require("./search"),
    details: require("./details")
};